function onLinkedInLoad()
{
var res = IN.Event.on(IN,"auth",onLinkedInAuth);	


}


function onLinkedInAuth()
{
alert('Welcome to technology gourps matching platform!');

var res =   IN.API.Profile("me")
.fields("firstName", "lastName", "location:(name)", "positions:(company:(name))", "educations:(school-name)", "picture-url", "specialties")
.result(displayProfiles);
}




function displayProfiles(profiles) {
    member = profiles.values[0];
    //alert(JSON.stringnify(profiles));

    
    

//}
//function onlinesearchClick()(
        		//member = profiles.values[0];
        var i;
        var groups = new Array();
        groups[0] = "http://www.memphisjug.org/";
        groups[1] = "https://www.java.net//jugs/java-user-groups";
        groups[2] = "http://tech.dir.groups.yahoo.com/dir/1600006905";
        groups[3] = "http://java.meetup.com/";
        groups[4] = "http://www.complang.tuwien.ac.at/english";
        groups[5] = "http://www.cplusplus.com/forum/beginner/35/";
        groups[6] = "http://publib.boulder.ibm.com/infocenter/zos/basics/index.jsp?topic=/com.ibm.db2z.doc.intro/db2z_stogroups.html";
        groups[7] = "http://www.eclipse.org/org/industry-workgroups/";
        groups[8] = "http://www.eclipse.org/org/industry-workgroups/industry_wg_process.php";
        groups[9] = "http://grokbase.com/groups";
        
        groups[10] = "http://www.hal9k.com/cug/";
        groups[11] = "http://www.meetup.com/Chicago-C-CPP-Users-Group/";
        groups[12] = "http://becpp.org/blog/";
        groups[13] = "http://www.meetup.com/Los-Angeles-Cpp/";
        groups[14] = "http://www.meetup.com/SF-Bay-Area-Cpp/";
        groups[15] = "http://www.dfwcpp.com/";
        groups[16] = "http://meetingcpp.com/index.php/c-user-group-nrw.html";
        groups[17] = "http://houstoncpp.com/";
        groups[18] = "https://groups.google.com/forum/?fromgroups#!forum/c-cpp-ug";
        groups[19] = "http://www.sfjava.org/";
        groups[20] = "http://java.meetup.com/cities/us/ca/san_jose/";
        groups[21] = "http://www.sacjug.org/";
        groups[22] = "http://www.hjug.org/";
        groups[23] = "http://trijug.org/";
        groups[24] = "http://www.ajug.org/";
        groups[25] = "http://www.sdjug.org/";
        groups[26] = "http://ojug.org/";
        groups[27] = "http://www.pjug.org/";
        groups[28] = "http://www.ocjug.org/";
        groups[29] = "http://www.meetup.com/jsmeetup/";
        groups[30] = "http://javascript.meetup.com/cities/us/ca/san_jose/";
        groups[31] = "http://www.meetup.com/sandiegojs/";
        groups[32] = "http://javascript.meetup.com/cities/us/ca/los_angeles/";
        groups[33] = "https://github.com/cincijs";
        groups[34] = "https://groups.google.com/forum/#!forum/nashjs";
        groups[35] = "http://baltimoretech.net/events/the-baltdc-javascript-users-group/";
        groups[36] = "https://groups.google.com/forum/?fromgroups#!forum/kcjug";
        groups[37] = "https://groups.google.com/forum/?fromgroups#!forum/cbusjs";
        groups[38] = "http://www.sydjs.com/";
        groups[39] = "http://python.meetup.com/cities/us/ca/san_jose/";
        groups[40] = "http://www.baypiggies.net/";
        groups[41] = "http://www.python.mn/";
        groups[41] = "http://www.python-academy.com/user-group/";
        groups[43] = "http://www.pyptug.org/";
        groups[44] = "http://www.ctpug.org.za/";
        groups[45] = "http://www.rocpy.org/";
        groups[46] = "http://pugip.org/";
        groups[47] = "http://pynash.org/";
        groups[48] = "http://clepy.org/";
        groups[49] = "http://www.chipy.org/";
        groups[50] = "http://www.trihug.org/";
       groups[51] = "http://hadoop.meetup.com/cities/us/ca/san_jose/";
        groups[52] = "http://austinhug.blogspot.com/";
        groups[53] = "http://www.uhug.org/";
        groups[54] = "http://hugfrance.fr/";
        groups[55] = "http://huguk.org/";
        groups[56] = "http://www.meetup.com/TorontoHUG/";
        groups[57] = "http://vimeo.com/chug";
        groups[58] = "http://www.meetup.com/Hadoop-DC/";
        groups[59] = "http://www.dfwbigdata.org/";
        groups[60] = "http://www.meetup.com/The-San-Francisco-SQL-Server-Meetup-Group/";
        /* groups[61] = "http://nycsqlusergroup.com/";
        		groups[62] = "http://www.sqlserverfaq.com/";
        		groups[63] = "http://www.tampasql.com/";
        		groups[64] = "http://www.pssug.org/";
        		groups[65] = "http://denver.sqlpass.org/";
        		groups[66] = "http://arizona.sqlpass.org/";
        		groups[67] = "http://www.sql.la/";
        		groups[68] = "http://richmondsql.org/cs2007/";
        		groups[69] = "http://sqloc.com/";
        		groups[70] = "http://www.phpusergroups.org/
        		groups[71] = "http://php.meetup.com/cities/us/ca/san_jose/";
        		groups[72] = "http://www.sfphp.org/";
        		groups[73] = "http://uphpu.org/";
        		groups[74] = "http://www.nashvillephp.org/";
                groups[75] = "http://www.meetup.com/orlandophp/";
        		groups[76] = "http://www.tcphp.org/";
        		groups[77] = "http://www.soflophp.org/";
        		groups[78] = "http://www.lrphp.org/";
        		groups[79] = "http://capcloud.azurewebsites.net/meetings.aspx";
        		groups[80] = "http://windowsazurecloud.ning.com/group/sandiegoazureusergroup";
        		groups[81] = "http://coccug.com/";
        		groups[82] = "https://groups.google.com/forum/#!forum/cloud-computing";
        		groups[83] = "http://blogs.msdn.com/b/peterlau/archive/2009/01/23/announcing-the-new-york-microsoft-cloud-computing-user-group.aspx";
        		groups[84] = "http://www.meetup.com/TampaCloud/";
        		groups[85] = "http://cloud-computing.meetup.com/cities/us/ca/san_francisco/";
        		groups[86] = "http://www.meetup.com/Chicagoazure/";
        		groups[87] = "http://cloud-computing.meetup.com/cities/us/ga/atlanta/";
        		groups[88] = "http://www.meetup.com/Dallas-Fort-Worth-Cloud-Computing-Meetup-Group/";
        		*/
        var names = new Array();
        names[0] = "Memphi";
        names[1] = "java.net ";
        names[2] = "google groups";
        names[3] = "Meet Groups";
        names[4] = "The complang Group";
        names[5] = "Beginner study group";
        names[6] = "DB2 groups";
        names[7] = "Eclipse groups";
        names[8] = "Eclipse Industry";
        names[9] = "Grokbase";
        names[10] = " C user group";
        names[11] = "Chicago C group";		
        names[12] = "BEL C++ group	";	
        names[13] = "LA C++ group";	
        names[14] = "SF C++ group";		
        names[15] = "DFW C++ group";		
        names[16] = "MEE C++ group";		
        names[17] = "HOU C++ group";		
        	names[18] = "GO C++ group";		
        	names[19] = "SF Java group";		
        	names[20] = "SJ Java Group";		
        	names[21] = "SAC Java Group";		
        	names[22] = "HOUS Java Group";		
        	names[23] = "Triangle JUG";		
        	names[24] = "ATL Java Group";		
        	names[25] = "SD Java Group";		
        	names[26] = "OMAHA JUG";		
        	names[27] = "PORTLAND JUG";		
        	names[28] = "OC Java Group";		
        	names[29] = "F JS group";		
        	names[30] = "SJ JS group";		
        	names[31] = "SD JS group";		
        	names[32] = "LA JS group";		
        	names[33] = "CIN JS group";		
        	names[34] = "NAS JS group";		
        	names[35] = "BAL JS group";		
        	names[36] = "KC JS group";		
        	names[37] = "COL JS group";		
        	names[38] = "SYD JS group";		
        	names[39] = "SJ py group";		
        	names[40] = "BA py group";		
        	names[41] = "TC py group";		
        	names[42] = "LZ py group";		
        	names[43] = "PYP py group";		
        	names[44] = "CT py group";		
        	names[45] = "ROC py group";		
        	names[46] = "PT py group";		
        	names[47] = "NL py group";		
        	names[48] = "CL py group";		
        	names[49] = "CHI py group";		
        	names[50] = "TRI ha group";		
       	    names[51] = "SJ had group";		
        	names[52] = "AUS had group";		
        	names[53] = "UT had group";		
        	names[54] = "HUG had group";		
        	names[55] = "UK had group";		
        	names[56] = "TOR had group";		
        	names[57] = "CHI had group";		
        	names[58] = "DC had group";		
        	names[59] = "DAL had group";		
        	names[60] = "SF sql group";		
        	 /*names[61] = "NYC sql group";		
        	names[62] = "UK sql group";		
        	names[63] = "TAM sql group";		
        	names[64] = "PHI sql group";		
        	names[65] = "DEN sql group";		
        	names[66] = "AZ sql group";		
        	names[67] = "LA sql group";		
        	names[68] = "RC sql group";		
        	names[69] = "OC sql group";		
        	names[70] = "PH php GROUP";		
        	names[71] = "SJ php group";		
        	names[72] = "SF php group";		
        	names[73] = "UT php group";		
        	names[74] = "NV php group";		
        	names[75] = "ORL php group";		
        	names[76] = "TC php group";		
        	names[77] = "FL php group";	
        	names[78] = "LR php group";	
        	names[79] = "CA cl group";		
        	names[80] = "SD cl group";		
        	names[81] = "CO cl group";		
        	names[82] = "GO cl group";	
        	names[83] = "NY cl group";
        	names[84] = "TB cl group";		
        	names[85] = "SF cl group";		
        	names[86] = "CHI cl group";		
        	names[87] = "ATL cl group";		
        	names[88] = "DAL cl group";		
        	*/
        onlinesearchHTML = "Search Results 10 :<ul>";
        if (member.specialties)
        	{
        	 
        	for (var num,i=0;i<10;i++)
            {
        		var n=parseInt(Math.random()*60+1); 
        		
	        	//document.write(groups[i] + "<br>");
	        
        		onlinesearchHTML = onlinesearchHTML + "<li>";
        		onlinesearchHTML = onlinesearchHTML + "<a href =" + groups[n] + ">"  + names[n] + "</a>"+" ";
        		onlinesearchHTML = onlinesearchHTML + "</li>";
        	
            }
        	
        	}
        else{
        
        	for (i=0;i<10;i++)
            {
        		var n=parseInt(Math.random()*60+1);       	
        	//document.write(groups[i] + "<br>");
        		 
        		
	        	//document.write(groups[i] + "<br>");
	        
        		onlinesearchHTML = onlinesearchHTML + "<li>";
        		onlinesearchHTML = onlinesearchHTML + "<a href =" + groups[n] + ">"  + names[n] + "</a>"+" ";
        		onlinesearchHTML = onlinesearchHTML + "</li>";
        	
            }
        }
    	
        onlinesearchHTML = onlinesearchHTML + "</ul>";
        document.getElementById("recommendresults").innerHTML = onlinesearchHTML;
        
        document.getElementById("name").innerHTML = "<p id=\"" +
        member.id + "\">" + member.firstName + " " + member.lastName + "<\p>";
            //document.getElementById("headline").innerHTML = "<p id=\"" +
            "abcdefg\">" + member.headline + "<\p";
                    document.getElementById("location").innerHTML = "<p id=\"" +
            "a01\">" + member.location.name + "<\p";
                    document.getElementById("school").innerHTML = "<p id=\"" +
            "a02\">" + member.educations.values[0].schoolName + "<\p";
                    document.getElementById("company").innerHTML = "<p id=\"" +
            "a02\">" + member.positions.values[0].company.name + "<\p";
                    document.getElementById("specialties").innerHTML = "<p id=\"" +
            "a03\">" + member.specialties + "<\p";
}


function searchClick() {
if (!IN.ENV.auth.oauth_token) {
  alert("You must login w/ LinkedIn to use the Search functionality!");
  return;
}

alert("Searching");

IN.API.Raw("/people/~/suggestions/groups?start=0&count=100")  
  .result(setSearchResults)
  .error(showError);
//window.location.href="groupmatch.html? backurl="+window.location.href;

}


function showError(msg)
{
	
	console.log(msg); 
	}

function setSearchResults(result) {
	searchHTML = "Search Results 10:<ul>";

	for (i in result.values) {
		  if(result.values[i].category.code == 'professional')
			  {
	  		searchHTML = searchHTML + "<li>";
	  		searchHTML = searchHTML + result.values[i].name + " ";
	  		searchHTML = searchHTML + //result.values[i].description + " " +
	  			   	"<button type='button' onclick=joinGroup('"+result.values[i].id+"')>Join Group</button></li>";
	  		 
	  		
	  		/*searchHTML = searchHTML + " (memberToken: " + result.people.values[i].id + ")</li>";*/
			  }
	}
	searchHTML = searchHTML + "</ul>";

	document.getElementById("searchresults").innerHTML = searchHTML;
	 
}


function joinGroup(grpID){
	//alert(grpID);
	IN.API.Raw("/people/~/group-memberships?group-id="+grpID).method("PUT")
	  .result(alert("Joined"));
}


